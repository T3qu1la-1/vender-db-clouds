
# 📁 Pasta CloudsAqui

Esta pasta é onde você deve colocar seus arquivos TXT/ZIP/RAR para processamento.

## Como usar:

1. Coloque seus arquivos .txt, .zip ou .rar aqui
2. Execute o terminal.py na pasta principal
3. O sistema irá detectar automaticamente os arquivos desta pasta

## Formatos suportados:
- Arquivos .txt com credenciais
- Arquivos .zip contendo TXTs
- Arquivos .rar contendo TXTs
- Tamanho máximo: 4GB por arquivo

## Resultados:
Os arquivos processados serão salvos na pasta principal com o formato:
- cloudbr-[nome]-GERAL-[data].txt
- cloudbr-[nome]-BR-[data].txt
