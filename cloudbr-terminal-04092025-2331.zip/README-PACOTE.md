# 📦 CloudBR Terminal - Pacote Standalone

## 🚀 Como usar:

### Windows (PowerShell/CMD):
```cmd
# Instalar Python se necessário
# Baixar o pacote e extrair

# Instalar dependências
pip install flask rarfile requests

# Executar
python terminal.py
```

### Linux/Mac:
```bash
# Instalar dependências
pip3 install flask rarfile requests

# Dar permissão ao script
chmod +x iniciar.sh

# Executar
./iniciar.sh
```

## 📁 Estrutura:
- terminal.py - Script principal do terminal
- iniciar.sh - Script de inicialização (Linux/Mac)
- cloudsaqui/ - Pasta para seus arquivos TXT/ZIP/RAR

## 💡 Instruções:
1. Coloque seus arquivos na pasta 'cloudsaqui'
2. Execute terminal.py
3. Escolha a opção de processamento
4. Resultados aparecerão na pasta principal

## 🇧🇷 Recursos:
- Filtro automático para URLs brasileiras
- Suporte a TXT/ZIP/RAR até 4GB
- Interface em português
- Processamento em lote
